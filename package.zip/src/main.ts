import fs from 'fs'
import ndarray, { NdArray } from 'ndarray'
import { getPixels, savePixels } from 'ndarray-pixels'
import { matrixToList, ndarrayToMatrix } from './Utils/NdArrayConverter';

const  convertNumArrayToHexString = (list) => {
  var result = [];
  for (var i = 0; i < list.length; i++) {
    //@ts-ignore
    result.push(list[i].toString(16));
  }
  return result.join(",");
}



  


(async () => {
  //Le arquivo da imagem
  var file = fs.readFileSync("./images/low.jpg");

  //Retorna os pixeis da imagem no formato matriz
  var pixels = await getPixels(file, 'image/jpeg');




    var a = ndarrayToMatrix(pixels);


    a.applyMedianTransformation("7x7", "vertical", "all");
    
    var k = matrixToList(a);
    
  
    //Salva os pixels alterados para um formato descrito
    const data = await savePixels(k, "image/png");
    fs.writeFileSync("./images/output.png", data);
  
})();
